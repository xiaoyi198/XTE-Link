"""Bounded, non-flashing serial smoke test against installed XTE-Link firmware."""

import argparse
import json
from pathlib import Path
import time

from .driver import collect_status, demo_status, open_serial
from .protocol import encode_status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True)
    parser.add_argument("--log", required=True)
    args = parser.parse_args()
    log_path = Path(args.log)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", encoding="utf-8") as log, open_serial(args.port) as connection:
        def note(message):
            print(message, flush=True)
            log.write(message + "\n")
            log.flush()

        def observe(seconds):
            deadline = time.monotonic() + seconds
            captured = bytearray()
            while time.monotonic() < deadline:
                if connection.in_waiting:
                    captured.extend(connection.read(min(connection.in_waiting, 4096)))
                time.sleep(0.02)
            text = captured.decode("utf-8", "replace")
            note(text.rstrip())
            if any(marker in text for marker in ("Guru Meditation", "panic", "Stack smashing")):
                raise AssertionError("device crash detected")
            return text

        def send(frame):
            if connection.write(frame) != len(frame):
                raise AssertionError("incomplete write")

        def accepted(text, count):
            actual = text.count("XTE: accepted")
            if actual != count:
                raise AssertionError(f"expected {count} acceptances, received {actual}")

        note("BOOT/IDLE LOGS")
        observe(6)
        frame = encode_status(demo_status())
        note("DEMO: CPU=12.5 MEMORY=7.0/16.0 GiB DISK=120.5 GiB")
        send(frame)
        text = observe(7)
        accepted(text, 1)
        if "XTE: rendered" not in text:
            raise AssertionError("accepted demo was not rendered")

        note("INVALID FRAMES: unsupported version, bool metric, out-of-range, trailing data")
        for field, value in (("v", 2), ("cpu", True), ("cpu", 101)):
            sample = demo_status()
            sample[field] = value
            send(json.dumps(sample).encode("ascii") + b"\n")
        send(frame[:-1] + b"garbage\n")
        accepted(observe(2), 0)

        note("OVERLONG LINE + FRAGMENTED VALID RECOVERY")
        send(b"x" * 500 + b"\n")
        send(frame[:30])
        time.sleep(0.1)
        send(frame[30:])
        accepted(observe(6), 1)

        note("NO VALID DATA: observe timeout refresh (screen state needs visual confirmation)")
        text = observe(17)
        accepted(text, 0)
        if "XTE: rendered" not in text:
            raise AssertionError("no timeout refresh observed")

        note("NULL METRICS")
        sample = demo_status()
        for key in ("cpu", "gpu", "gpu_temp_c", "mem_used_mib", "mem_total_mib"):
            sample[key] = None
        send(encode_status(sample))
        accepted(observe(6), 1)

        note("LIVE PC DATA (three frames)")
        import psutil
        psutil.cpu_percent(interval=None)
        time.sleep(1)
        for _ in range(3):
            sample = collect_status()
            note(encode_status(sample).decode("ascii").rstrip())
            send(encode_status(sample))
            text = observe(6)
            accepted(text, 1)
            if "XTE: rendered" not in text:
                raise AssertionError("live frame was not rendered")
        note("PASS: acceptance, rejection, recovery, refresh and live data; visual QA remains separate")


if __name__ == "__main__":
    main()
