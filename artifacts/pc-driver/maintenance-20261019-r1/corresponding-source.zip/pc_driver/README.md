# PC driver

## Windows EXE / 系统托盘

构建好的单文件程序位于 `artifacts/pc-driver/<构建时间>/XTE-Link.exe`。
双击即可运行，无需安装 Python，无控制台窗口。系统托盘显示 XTE-Link 图标；
如果图标被 Windows 收起，可在任务栏的隐藏图标区域找到。
右键可查看连接状态、选择串口、打开日志或退出。
新增连接方式、设备选择、USB WiFi 配置与驱动设置窗口。
默认仅在检测到一个 VID:PID `303A:1001` 的 ESP32 USB-Serial/JTAG 串口时自动连接；
多设备时通过菜单手动选择。选择会保存到 `%USERPROFILE%/.xte-link/tray.json`，
日志位于同目录 `driver.log`（2 MiB 滚动，保留两份旧日志）。

## 局域网与即时推送

使用 `lan-push-20261014` 或更新的兼容固件。首次通过 USB 连接后，在配置窗口填写
2.4 GHz WiFi 名称和密码；TF 卡须已挂载。配置经分块传输及 SHA-256 校验后保存到
`/xte-link/network.json`。更新配置先验证候选文件，再通过保留旧文件的重命名提交；
中途失败可重试。密码以明文保存在 TF，电脑只保存设备身份和配对密钥。

固件设置手动选择“串口直连”或“局域网连接”，驱动默认自动跟随。
USB 可在局域网模式下继续用于配置和 TF 工具，但仅固件选中的方式传输状态与按键操作。
局域网使用 mDNS 发现已配对设备；IP 变化后重新发现，多设备时使用设备菜单选择。
自动发现受网络隔离或防火墙影响时，可在驱动设置输入设备信息页中的 IP。
固定选择驱动连接方式时，固件也需选择同一种方式。

驱动设置可修改常规推送间隔（5～3600 秒，默认 5 秒）。心跳每 5 秒发送，
固件 15 秒没有有效通信判离线；心跳不改变指标的最后更新时间。
DSH 与 Codex 桌面事件唤醒发送，`agents.json` 桥接每 250 毫秒检查变化；事件与常规周期独立。
传感器在单独线程采集，AI 发送不等待 GPU 查询。助手页收到变化会在屏幕可用时刷新，
其他页面保留当前位置，设备上的普通屏幕更新间隔仍独立生效。
Codex 桌面通过本机 `codex-ipc` 命名管道自动接入，订阅当前已加载聊天的状态。
命令与文件审批使用设备 ✓ 单次批准、顶部 → 拒绝；原生请求 ID 的类型保持不变，
拒绝优先使用该请求提供的 `decline`，只有 `cancel` 时取消本轮，不选择记住规则或会话批准。
设备使用 32 字符临时 ID，驱动校验聊天、原请求、所属客户端和连接状态。
电脑先处理、请求变更、所属客户端退出、断线或增量版本不连续都会使旧设备 ID 失效。
返回成功只表示桌面接受回传，完成状态由真实任务状态决定。回传失败或无回执时提示在电脑处理，
不自动重试、不模拟 Codex Enter/Esc。连接断开时 Codex 显示离线，文件桥不能覆盖实时来源。
复杂问题、MCP 表单和权限范围选择在电脑处理；部分子代理需在桌面打开聊天后才会发布原生请求。
独立 CLI 会话不支持本次桌面接入。IPC 是内部协议，已核对桌面 `26.1013.4894.0`；
适配参考 codex-mobile commit `f79e6807ca0b9d6052afd24f822ee41b9a52e07d`（MIT）。
无需为本次驱动升级刷写固件。

```powershell
.\.venv\Scripts\python.exe -m pc_driver.driver --mode auto --interval 30
.\.venv\Scripts\python.exe -m pc_driver.driver --mode lan --host 192.168.1.50 --interval 60
```

LAN 使用 TCP 8765，固件 `_xte-link._tcp.local.` 服务只发布设备 ID。
首次 USB 配置交换随机 32 字节配对密钥；握手以随机 nonce 做双向 HMAC-SHA256 验证。
每帧格式是网络字节序 `uint32 sequence + uint16 length + payload + 32-byte HMAC`；
认证输入为 `C:` 或 `S:`、32 字节 nonce ASCII、帧头及 payload。payload 含结尾换行，
最大 385 字节；不同方向、会话、顺序及篡改均拒绝。该机制验证消息真实性，不加密内容。
JSON 状态保持 v2；新增 `hello`、`heartbeat`、单助手 `agents` 控制帧，USB 专用
`network_commit` 用于提交候选配置。正常设置和连接模式分别持久化，恢复默认切回串口，
保留 TF WiFi 文件、字库和原有恢复路径。
串口断开或被占用时会重试；先退出旧 Python 驱动及串口监视器。
重复双击只保留一个托盘实例，退出会释放串口；未设置开机自启。

从项目根目录重新构建：

```powershell
.\.venv\Scripts\python.exe -m pip install -r pc_driver/requirements-build.txt
.\.venv\Scripts\python.exe -m unittest pc_driver.test_driver pc_driver.test_tray -v
.\.venv\Scripts\python.exe scripts/build_driver.py
```

每次构建使用独立目录，附带 `SHA256SUMS.txt`、构建依赖版本和使用说明。
开发时也可通过 `.\.venv\Scripts\pythonw.exe -m pc_driver.tray` 启动托盘版本。
托盘复用 [pystray 0.19.5](https://github.com/moses-palmer/pystray)，
图标使用 [Pillow 12.3.0](https://github.com/python-pillow/Pillow)，
打包使用 [PyInstaller 6.22.3](https://github.com/pyinstaller/pyinstaller)
及 hooks-contrib 2026.8，版本固定在 `requirements-build.txt`。

## CLI

Run commands from the project root. This is a user-space telemetry program,
not a Windows kernel driver. The first transport is USB CDC serial.

TF-card file commands are in `pc_driver.tf`; see [TF_FILES.md](../TF_FILES.md).
Close the telemetry driver and serial monitors before running these commands.

```powershell
.\.venv\Scripts\python.exe -m pip install -r pc_driver/requirements.txt
.\.venv\Scripts\python.exe -m pc_driver.driver --demo --once
.\.venv\Scripts\python.exe -m pc_driver.driver --once
.\.venv\Scripts\python.exe -m pc_driver.driver --list-ports
.\.venv\Scripts\python.exe -m unittest pc_driver.test_driver -v
```

After compatible XTE-Link firmware has been installed and verified:

```powershell
.\.venv\Scripts\python.exe -m pc_driver.driver --port COM3
```

The default update interval is 5 seconds (configurable from 5 to 3600 seconds). `--demo --port COM3` sends sample
data instead of live metrics. Without `--port`, frames are printed to stdout.
`--once` exits after one frame; with a port it drains device logs for 5 seconds.
This confirms transmission only, not rendering. Normal operation retries a
disconnected port every second; Ctrl+C exits. Other serial monitors must be
closed. Device logs are drained and printed to stderr. DTR/RTS are set low
before opening; actual USB/OS reset behavior still requires device testing.

CPU's first nonblocking sample is discarded. Memory usage is total minus
available. CPU temperature comes from psutil sensors where supported. Windows leaves it null;
ACPI thermal-zone readings are not treated as CPU temperature.
On Windows, AMD GPU activity and core/edge temperature come from the installed
AMD driver's ADL2_New_QueryPMLogData_Get in System32/atiadlxx.dll. No driver
installation or administrator rights are required for this AMD query. Sensor
support flags and API return codes are checked on every sample. Display entries
are deduplicated by PCI bus/device/function; exactly one temperature-capable GPU
must be present, otherwise both AMD metrics remain null. This selects the RX 9070
XT on the verified host without averaging it with the integrated GPU. GPU activity
uses AMD's GFX activity percentage, which can differ from Task Manager's busiest
engine utilization. GPU temperature uses edge/core temperature, not hotspot.
NVIDIA-only hosts retain nvidia-smi collection, now including temperature; multiple
NVIDIA GPUs are not averaged.
The PC field gpu_temp_c is included within protocol v2's frame limit.
The existing driver also reads the Windows default playback endpoint volume and
includes it as `volume`. Firmware volume-page Left/Right commands are consumed
by this same process and adjust the master volume by the device's saved step:
1, 5 or 10 percentage points (default 5). Restart the driver after updating its
source so the new step values are accepted; older drivers only accept +/-5.
The same process immediately returns the actual endpoint volume with the command
sequence in `volume_ack`, using cached metrics to avoid another sensor query.
The current firmware source expects and displays GPU temperature. Older v2
firmware ignores the extra field. This PC change does not flash or edit firmware.

Collection failures or unsupported sensors produce
`null`, not zero. Host names use printable ASCII
(non-ASCII characters become `?`). Fixed firmware labels now use the TF-card
Chinese font; PC-supplied names and request text remain ASCII in protocol v2.

Dependencies: [psutil](https://github.com/giampaolo/psutil) 7.0.0 and
[pyserial](https://github.com/pyserial/pyserial) 3.5, pinned in requirements.txt.

AMD ABI reference: [LibreHardwareMonitor v0.9.6](https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/blob/v0.9.6/LibreHardwareMonitorLib/Interop/AtiAdlxx.cs) and [AMD ADL SDK](https://github.com/GPUOpen-LibrariesAndSDKs/display-library). No third-party sensor package was installed.
