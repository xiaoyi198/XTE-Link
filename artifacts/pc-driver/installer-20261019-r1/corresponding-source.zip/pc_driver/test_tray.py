"""Checks for tray port selection and cooperative driver shutdown."""

import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

from pc_driver.driver import main
from pc_driver.tray import automatic_port, TrayApp


class TrayTests(unittest.TestCase):
    def test_auto_port_ignores_unrelated_and_ambiguous_devices(self):
        other = SimpleNamespace(device="COM1", vid=None, pid=None)
        x4 = SimpleNamespace(device="COM3", vid=0x303A, pid=0x1001)
        second = SimpleNamespace(device="COM4", vid=0x303A, pid=0x1001)
        self.assertIsNone(automatic_port([other]))
        self.assertEqual(automatic_port([other, x4]), "COM3")
        self.assertIsNone(automatic_port([x4, second]))

    def test_port_selection_stops_old_session_and_survives_restart(self):
        with tempfile.TemporaryDirectory() as folder, patch("pc_driver.tray.pystray.Icon"):
            app = TrayApp(Path(folder))
            app.select_port("COM7")(app.icon, None)
            self.assertTrue(app.session_stop.is_set())
            self.assertEqual(TrayApp(Path(folder)).selected_port, "COM7")
            app.select_port(None)(app.icon, None)
            self.assertIsNone(TrayApp(Path(folder)).selected_port)

    def test_bad_saved_port_is_ignored(self):
        with tempfile.TemporaryDirectory() as folder, patch("pc_driver.tray.pystray.Icon"):
            path = Path(folder) / "tray.json"
            for raw in ('{"port":"loop://"}', '[]', 'bad JSON'):
                path.write_text(raw, encoding="utf-8")
                self.assertIsNone(TrayApp(Path(folder)).selected_port)

    def test_exit_stops_session_and_tray(self):
        with tempfile.TemporaryDirectory() as folder, patch("pc_driver.tray.pystray.Icon"):
            app = TrayApp(Path(folder))
            app.quit(app.icon, None)
            self.assertTrue(app.stop_event.is_set())
            self.assertTrue(app.session_stop.is_set())
            app.icon.stop.assert_called_once()

    def test_driver_shutdown_releases_serial_and_bridge(self):
        stop = threading.Event()
        connection = Mock(in_waiting=0)

        def write(frame):
            value = json.loads(frame)
            if "host" in value:
                self.assertEqual(value["host"], "DEMO-PC")
                stop.set()
            return len(frame)

        connection.write.side_effect = write
        callback = Mock()
        with patch("pc_driver.driver.open_serial", return_value=connection), \
             patch("pc_driver.driver.AgentManager") as manager, \
             patch("pc_driver.driver.WindowsVolume"), \
             patch("pc_driver.driver.sys.stderr"):
            self.assertEqual(main(["--demo", "--port", "COM3"], stop, callback), 0)
        callback.assert_called_once_with(True, "USB COM3")
        connection.close.assert_called_once()
        manager.return_value.close.assert_called_once()


if __name__ == "__main__":
    unittest.main()
